﻿using System.Web.Mvc;

namespace NexmoDotNetQuickStarts.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}